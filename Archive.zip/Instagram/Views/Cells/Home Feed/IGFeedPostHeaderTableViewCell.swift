//
//  IGFeedPostHeaderTableViewCell.swift
//  Instagram
//
//  Created by Ilham Huda on 27/01/21.
//

import UIKit

class IGFeedPostHeaderTableViewCell: UITableViewCell {

    

}
