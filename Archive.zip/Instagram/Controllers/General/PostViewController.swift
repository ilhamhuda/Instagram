//
//  PostViewController.swift
//  Instagram
//
//  Created by Ilham Huda on 20/01/21.
//

import UIKit

class PostViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

}
