//
//  CameraViewController.swift
//  Instagram
//
//  Created by Ilham Huda on 19/01/21.
//

import UIKit

class CameraViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        navigationController?.setNavigationBarHidden(true, animated: false)
    }
    
    private func didTapTakePicture() {
        
    }


}
